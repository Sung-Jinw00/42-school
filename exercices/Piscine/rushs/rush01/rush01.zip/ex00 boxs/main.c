/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.c                                             :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: marvin <marvin@student.42.fr>              +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/16 18:07:35 by marvin            #+#    #+#             */
/*   Updated: 2024/10/22 09:15:24 by marvin           ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "r01boxs.h"

int	ft_strlen(char *str)
{
	int	i;

	i = 0;
	if (!(str[i] >= '0' && str[i] <= '9'))
		return (ft_error());
	while (str[i])
	{
		if (!(str[i] >= '0' && str[i] <= '9') && !str[i])
			return (ft_error());
		else if (str[i] >= '0' && str[i] <= '9')
			i += 2;
		else
			return (i / 2);
	}
	return (ft_error());
}

int	go_to_r01(char **av, int val_max)//je verifie que j'ai des chiffres valides
{
	int	i;

	i = 0;
	while (av[1][i] && i < ft_strlen(av[1]) - 1)
	{
		if ((av[1][i] >= '1' && av[1][i] <= (val_max + 48)) && av[1][i])
			i += 2;
		else
			return (ft_error());
	}
	return (1);
}

int	ft_if_ac_2(char **av, int val_max)
{
	int	len;

	len = ft_strlen(av[1]);//je prends la len de mes arguments
	if (len == 16 || len == 20 || len == 24
		|| len == 28 || len == 32 || len == 36)//si j'ai le bon nb cond
	{
		while (val_max < 10 && val_max * 4 != len)//j'ajuste ma val max si besoin
			val_max++;
		if (go_to_r01(av, val_max) == 1)
		{
			if (!rush01(av, val_max))
				return (0);
		}
	}
	return (ft_error());//sinon erreur
}

int	main(int ac, char **av)
{
	int	val_max;

	val_max = 4;//val max min
	if (ac == 2)//si j'ai le bon nombre d'args
		ft_if_ac_2(av, val_max);
	else
		return (ft_error());
	return (0);
}